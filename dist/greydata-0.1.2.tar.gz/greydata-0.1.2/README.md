# Greydata

Greydata is a Python library for processing and analyzing data.

## Installation

```bash
pip install greydata
```

## Usage

```python
from greydata import module1

print(module1.hello())
```

