# greydata/welcome.py

def hello():
    return "Hello from greydata!"
