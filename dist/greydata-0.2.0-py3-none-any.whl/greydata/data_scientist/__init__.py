"""
This module contains functions and classes for data science tasks.
"""

from .module_code import model_data
