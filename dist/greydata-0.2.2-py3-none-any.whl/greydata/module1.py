# greydata/module1.py

def hello():
    return "Hello from greydata!"

def add_numbers(a, b):
    return a + b
