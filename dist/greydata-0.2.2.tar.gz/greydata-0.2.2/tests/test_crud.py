from greydata import data_engineer as DE


if __name__ == "__main__":
    DE.run_crud_ui()
